﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Data
{
    public sealed class ApplicantConfiguration : IEntityTypeConfiguration<Applicant>
    {
        public void Configure(EntityTypeBuilder<Applicant> builder)
        {
            builder.ToTable(nameof(Applicant));

            builder.HasKey(auth => auth.Id);

            builder.Property(auth => auth.Id).ValueGeneratedOnAdd().IsRequired();
            builder.Property(auth => auth.Name).HasMaxLength(200).IsRequired();
            builder.Property(auth => auth.FamilyName).HasMaxLength(200).IsRequired();
            builder.Property(auth => auth.Address).HasMaxLength(500).IsRequired();
            builder.Property(auth => auth.CountryOfOrigin).HasMaxLength(200).IsRequired();
            builder.Property(auth => auth.EmailAddress).HasMaxLength(500).IsRequired();
            builder.Property(auth => auth.Age).IsRequired();
            builder.Property(auth => auth.Hired).HasDefaultValue(0).IsRequired();
        }
    }
}
