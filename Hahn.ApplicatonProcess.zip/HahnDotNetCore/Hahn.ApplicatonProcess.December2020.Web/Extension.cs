﻿using DotNetCore.AspNetCore;
using DotNetCore.EntityFrameworkCore;
using DotNetCore.IoC;
using Hahn.ApplicatonProcess.December2020.Data;
using Hahn.ApplicatonProcess.December2020.Domain;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Hahn.ApplicatonProcess.December2020.Web
{
    public static class Extensions
    {
        public static void AddContext(this IServiceCollection services)
        {
            var connectionString = services.GetConnectionString(nameof(Context));
            var options = new DbContextOptionsBuilder<Context>()
                      .UseInMemoryDatabase(databaseName: connectionString)
                      .Options;
            var context = new Context(options);
            services.AddUnitOfWork<Context>();
        }
        public static void AddServices(this IServiceCollection services)
        {
            services.AddFileExtensionContentTypeProvider();
            services.AddClassesInterfaces(typeof(IApplicantOperations).Assembly);
            services.AddClassesInterfaces(typeof(IApplicantRepository).Assembly);
        }
    }
}
