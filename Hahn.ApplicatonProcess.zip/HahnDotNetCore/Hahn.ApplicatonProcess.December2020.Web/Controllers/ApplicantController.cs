﻿using DotNetCore.AspNetCore;
using Hahn.ApplicatonProcess.December2020.Data;
using Hahn.ApplicatonProcess.December2020.Domain;
using Hahn.ApplicatonProcess.December2020.Domain.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Swashbuckle.AspNetCore.Annotations;
using Swashbuckle.AspNetCore.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web.Controllers
{
    [Route("api")]
    [ApiController]
    public class ApplicantController : Controller
    {
        ILogger<ApplicantController> _logger;
        IApplicantOperations _applicantOperations;
        public ApplicantController(ILogger<ApplicantController> logger,
            IApplicantOperations applicantOperations)
        {
            _logger = logger;
            _applicantOperations = applicantOperations;
        }
        /// <summary>
        /// Get All Applicants.
        /// </summary>
        [HttpGet]
        [Route("applicants")]
        public async Task<IActionResult> GetAllApplicants()
        {
            try
            {
                var response = await _applicantOperations.GetAllApplicantAsync();
                return CustomResponse(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error");
                return BadRequest(ex);
            }

        }
        /// <summary>
        /// Get an Applicant.
        /// </summary>
        [HttpGet]
        [Route("applicants/{id}")]
        public async Task<IActionResult> GetApplicantById(long id)
        {
            try
            {
                var response = await _applicantOperations.GetApplicantByIdAsync(id);
                return CustomResponse(response);

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error");
                return BadRequest(ex);
            }
        }

        /// <summary>
        /// Creates an Applicant.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST
        ///     {
        ///         "name" : "Jack Rayn",
        ///         "familyName" : "Rayn Desoza",
        ///         "address" : "123 Franklen street",
        ///         "countryOfOrigin" : "Germany",
        ///         "emailAddress" : "jack@magree.com",
        ///         "age" : 33,
        ///         "hired" : true
        ///     }
        ///
        /// </remarks>
        /// <param name="applicantModel"></param>
        /// <returns>A newly created Applicant</returns>
        /// <response code="201">Returns the newly created Applicant</response>
        /// <response code="400">If the item is null</response>  

        [HttpPost]
        [Route("applicants")]
        public async Task<IActionResult> AddApplicant(ApplicantModel applicantModel)
        {
            try
            {
                var response = await _applicantOperations.AddApplicantAsync(applicantModel);
                return CustomAddResponse(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error");
                return BadRequest(ex);
            }
        }
        /// <summary>
        /// Updates an Applicant.
        /// </summary>
        /// <remarks>
        /// Sample request:
        ///
        ///     POST
        ///     {
        ///         "id" : 1,
        ///         "name" : "Jack Rayn",
        ///         "familyName" : "Rayn Desoza",
        ///         "address" : "123 Franklen street",
        ///         "countryOfOrigin" : "Germany",
        ///         "emailAddress" : "jack@magree.com",
        ///         "age" : 33,
        ///         "hired" : true
        ///     }
        ///
        /// </remarks>
        /// <param name="applicantModel"></param>
        /// <returns>update Applicant</returns>
        /// <response code="200">Returns the newly created Applicant</response>
        /// <response code="400">If the item is null</response>  
        [HttpPut]
        [Route("applicants")]
        public async Task<IActionResult> UpdateApplicant(ApplicantModel applicantModel)
        {
            try
            {
                var response = await _applicantOperations.UpdateApplicantAsync(applicantModel);
                return CustomResponse(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error");
                return BadRequest(ex);
            }
        }
        /// <summary>
        /// Delete an Applicant.
        /// </summary>
        [HttpDelete]
        [Route("applicants/{id}")]
        public async Task<IActionResult> DeleteApplicant(long id)
        {
            try
            {
                var response = await _applicantOperations.DeleteAsync(id);
                return CustomResponse(response);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error");
                return BadRequest(ex);
            }
        }

        private IActionResult CustomResponse(CustomResponse<ApplicantModel> response)
        {
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response);
            }
        }

        private IActionResult CustomResponse(CustomResponse<IEnumerable<ApplicantModel>> response)
        {
            if (response.IsSuccess)
            {
                return Ok(response);
            }
            else
            {
                return BadRequest(response);
            }
        }

        private IActionResult CustomAddResponse(CustomResponse<ApplicantModel> response)
        {
            if (response.IsSuccess)
            {
                string ApplicantUrl = this.Url.ActionLink("GetApplicantById", "Applicant", new { id = response.Data.Id });

                response.UpdateUrl(ApplicantUrl);
                response.UpdateDataType(null);

                return Created(ApplicantUrl, response);
            }
            else
            {
                return BadRequest(response);
            }
        }
    }
}
