﻿using AutoMapper;
using Hahn.ApplicatonProcess.December2020.Data;
using Hahn.ApplicatonProcess.December2020.Domain;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web.Utils
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            IHttpContextAccessor httpContextAccessor = new HttpContextAccessor();
            CreateMap<Applicant, ApplicantModel>().ReverseMap();
            //CreateMap<IEnumerable<Applicant>, IEnumerable<ApplicantModel>>().ReverseMap();
            CreateMap<Applicant, Applicant>().ReverseMap();
        }
    }
}
