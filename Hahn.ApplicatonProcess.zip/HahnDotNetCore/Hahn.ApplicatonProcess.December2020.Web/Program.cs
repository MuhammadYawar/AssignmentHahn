using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Web
{
    public class Program
    {
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }

        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            var configSettings = new ConfigurationBuilder()
                                .AddJsonFile("appsettings.json")
                                .Build();
    
            Log.Logger = new LoggerConfiguration()
                .WriteTo.File(string.Format(configSettings["Logging:WriteTo:LogPath"], DateTime.Now.Date.ToString("MM-dd-yyyy")) 
                , rollOnFileSizeLimit: Convert.ToBoolean(configSettings["Logging:WriteTo:IsFileSizeLimit"]), 
                fileSizeLimitBytes: Convert.ToInt64(configSettings["Logging:WriteTo:FileSizeLimit"]))
                .CreateLogger();

            return Host.CreateDefaultBuilder(args)
            .ConfigureAppConfiguration(config =>
            {
                config.AddConfiguration(configSettings);
            })
            .ConfigureLogging(logging =>
            {
                logging.AddSerilog();
            })
            .ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder.UseStartup<Startup>();
            });
        }
    }
}
