﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain
{
    public class ErrorMessage
    {
        public const string Success = "Success."; 
        public const string ApplicantNotExist = "Applicant does not exist."; 
        public const string ApplicantAddedSuccessfuly = "Applicant added successfuly."; 
        public const string ApplicantUpdatedSuccessfuly = "Applicant updated successfuly."; 
        public const string ApplicantDeletedSuccessfuly = "Applicant deleted successfuly."; 
    }
}
