﻿using DotNetCore.Results;
using Hahn.ApplicatonProcess.December2020.Domain.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain
{
    public interface IApplicantOperations
    {    /// <summary>
         /// Get all applicants
         /// </summary>
         /// <returns>CustomResponse<IEnumerable<ApplicantModel>></returns>
        Task<CustomResponse<IEnumerable<ApplicantModel>>> GetAllApplicantAsync();
        /// <summary>
        /// Get applicant by id
        /// </summary>
        /// <param name="id">applicant id</param>
        /// <returns>CustomResponse<ApplicantModel></returns>
        Task<CustomResponse<ApplicantModel>> GetApplicantByIdAsync(long id);
        /// <summary>
        /// Add applicant
        /// </summary>
        /// <param name="applicantModel">applicant model</param>
        /// <returns>CustomResponse<ApplicantModel></returns>
        Task<CustomResponse<ApplicantModel>> AddApplicantAsync(ApplicantModel applicantModel);
        /// <summary>
        /// Update applicant
        /// </summary>
        /// <param name="applicantModel">applicant model with existing id</param>
        /// <returns>CustomResponse<ApplicantModel></returns>
        Task<CustomResponse<ApplicantModel>> UpdateApplicantAsync(ApplicantModel applicantModel);
        /// <summary>
        /// Delete applicant by id
        /// </summary>
        /// <param name="id">applicant id</param>
        /// <returns>CustomResponse<ApplicantModel></returns>
        Task<CustomResponse<ApplicantModel>> DeleteAsync(long id);
    }
}
