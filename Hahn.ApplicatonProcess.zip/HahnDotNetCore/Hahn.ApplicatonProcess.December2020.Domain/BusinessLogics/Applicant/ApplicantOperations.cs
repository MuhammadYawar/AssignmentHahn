﻿using AutoMapper;
using DotNetCore.EntityFrameworkCore;
using DotNetCore.Validation;
using Hahn.ApplicatonProcess.December2020.Data;
using Hahn.ApplicatonProcess.December2020.Domain.Model;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain
{
    public class ApplicantOperations : IApplicantOperations
    {
        private readonly IUnitOfWork _unitOfWork;
        private readonly IApplicantRepository _applicantRepository;
        private readonly IMapper _mapper;
        private readonly IHttpClientFactory _httpClientFactory;
        public ApplicantOperations(IUnitOfWork unitOfWork,
            IApplicantRepository applicantRepository, IMapper mapper, IHttpClientFactory httpClientFactory)
        {
            _unitOfWork = unitOfWork;
            _applicantRepository = applicantRepository;
            _mapper = mapper;
            _httpClientFactory = httpClientFactory;
        }

        public async Task<CustomResponse<IEnumerable<ApplicantModel>>> GetAllApplicantAsync()
        {
            var applicantList = await _applicantRepository.ListAsync();
            if (applicantList == null || 
                (applicantList != null && applicantList.Count() == 0))
            {
                return new CustomResponse<IEnumerable<ApplicantModel>>(ErrorMessage.ApplicantNotExist);
            }
            var applicantModel = _mapper.Map<IEnumerable<ApplicantModel>>(applicantList.ToList());
            return new CustomResponse<IEnumerable<ApplicantModel>>(ErrorMessage.Success, data: applicantModel);
        }

        public async Task<CustomResponse<ApplicantModel>> GetApplicantByIdAsync(long id)
        {
            var applicant = await _applicantRepository.GetAsync(id);
            if (applicant == null)
            {
                return new CustomResponse<ApplicantModel>(ErrorMessage.ApplicantNotExist);
            }
            var applicantModel = _mapper.Map<ApplicantModel>(applicant);
            return new CustomResponse<ApplicantModel>(ErrorMessage.Success, data: applicantModel);
        }

        public async Task<CustomResponse<ApplicantModel>> AddApplicantAsync(ApplicantModel applicantModel)
        {
            var validation = await new AddApplicantValidator(_httpClientFactory).ValidationAsync(applicantModel);
            if (validation.Failed)
            {
                return new CustomResponse<ApplicantModel>(validation.Message, false);
            }

            var applicant = _mapper.Map<Applicant>(applicantModel);

            await _applicantRepository.AddAsync(applicant);
            await _unitOfWork.SaveChangesAsync();
            
            applicantModel.Id = applicant.Id;
            return new CustomResponse<ApplicantModel>(ErrorMessage.ApplicantAddedSuccessfuly, data: applicantModel);
        }

        public async Task<CustomResponse<ApplicantModel>> UpdateApplicantAsync(ApplicantModel applicantModel)
        {
            var validation = await new UpdateApplicantValidator(_httpClientFactory).ValidationAsync(applicantModel);
            if (validation.Failed)
            {
                return new CustomResponse<ApplicantModel>(validation.Message, false);
            }

            var applicant = await _applicantRepository.GetAsync(applicantModel.Id);
            if (applicant == null)
            {
                return new CustomResponse<ApplicantModel>(ErrorMessage.ApplicantNotExist, false);
            }

            var mappedApplicant = _mapper.Map<Applicant>(applicantModel);

            await _applicantRepository.UpdateAsync(applicant.Id, mappedApplicant);
            await _unitOfWork.SaveChangesAsync();

            return new CustomResponse<ApplicantModel>(ErrorMessage.ApplicantUpdatedSuccessfuly);
        }

        public async Task<CustomResponse<ApplicantModel>> DeleteAsync(long id)
        {
            await _applicantRepository.DeleteAsync(id);

            await _unitOfWork.SaveChangesAsync();

            return new CustomResponse<ApplicantModel>(ErrorMessage.ApplicantDeletedSuccessfuly);
        }
    }
}
