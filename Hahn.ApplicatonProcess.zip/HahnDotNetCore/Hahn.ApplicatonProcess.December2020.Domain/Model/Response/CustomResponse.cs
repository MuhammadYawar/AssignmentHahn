﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain.Model
{
    public sealed class CustomResponse<T> where T : class
    {
        public CustomResponse(string message, bool isSuccess = true, T data = null)
        {
            IsSuccess = isSuccess;
            Message = message;
            Data = data;
        }
        public bool IsSuccess { get; private set; }
        public string Message { get; private set; }
        public T Data { get; private set; }
        public string Url { get; private set; }
        public bool HasData { get { return Data != null; } private set { HasData = value; } }

        public void UpdateDataType(T data)
        {
            Data = data;
        }

        public void UpdateUrl(string url)
        {
            Url = url;
        }
    }
}
