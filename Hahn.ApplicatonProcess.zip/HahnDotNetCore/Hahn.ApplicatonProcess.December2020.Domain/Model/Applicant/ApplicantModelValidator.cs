﻿using FluentValidation;
using Hahn.ApplicatonProcess.December2020.Domain.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace Hahn.ApplicatonProcess.December2020.Domain
{
    public abstract class ApplicantModelValidator : AbstractValidator<ApplicantModel>
    {
        public void Id()
        {
            RuleFor(x => x.Id).NotEmpty();
        }
        public void IdOnAdd()
        {
            RuleFor(x => x.Id).Empty();
        }

        public void EmailAddress()
        {
            RuleFor(x => x.EmailAddress).EmailAddress();
        }

        public void Name()
        {
            RuleFor(x => x.Name).NotEmpty().MinimumLength(5);
        }

        public void FamilyName()
        {
            RuleFor(x => x.FamilyName).NotEmpty().NotEmpty().MinimumLength(5);
        }

        public void Address()
        {
            RuleFor(x => x.Address).NotEmpty().MinimumLength(10);
        }

        public void Age()
        {
            RuleFor(x => x.Age).LessThanOrEqualTo(60).GreaterThanOrEqualTo(20);
        }
        public void CountryOfOrigin(IHttpClientFactory httpClientFactory)
        {
            RuleFor(x => x.CountryOfOrigin).NotEmpty()
                .Custom((val, context) =>
            {
                string url = string.Format("https://restcountries.eu/rest/v2/name/{0}?fullText=true", val);
                 bool isValid = HttpHelper.CheckOriginCountry(url, httpClientFactory);
                if (!isValid)
                {
                    context.AddFailure("'CountryOfOrigin' must be valid");
                }
            });
        }

        public void Hired()
        {
            RuleFor(x => x.Hired).NotNull();
        }
    }
}
