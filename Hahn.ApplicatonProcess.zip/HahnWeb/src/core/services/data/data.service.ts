import { AppConfigService } from './../common/app-config.service';
import { ResponseModel } from './../../models/response';
import { autoinject, inject } from 'aurelia-dependency-injection';
import { HttpClient } from 'aurelia-fetch-client';

@inject(HttpClient, AppConfigService)
export class DataService {
  http: HttpClient;
  baseURL: string;
  constructor(http: HttpClient, private appConfigService: AppConfigService) {
    this.http = http;
    const apiUrl = this.appConfigService.getConfig().API_MAIN_URL;
    this.configureURL(apiUrl);
    this.configureHttp(http, apiUrl);
  }
  private configureHttp(http, baseUrl){
    
    http.configure(config => {
      config.withBaseUrl(baseUrl);
      config.withInterceptor({
        request(request) {
          return request;
        }
      })
        .withDefaults({
          'mode': 'cors',
          headers: {
            'Content-type': `application/json; charset=utf-8`
          }
        });
    })
  }
  private configureURL(baseURL: string): void {
    this.baseURL = baseURL;
  }

  getAsync<T>(endpoint: string): Promise<ResponseModel<T>> {
    return this.http.get(endpoint)
      .then(response => response.json())
      .then(res => {
        return res;
      })
      .catch(error => {
        console.log('Something went wrong.');
        return [];
      });
  }

  postAsync<T>(endpoint: string, data: any): Promise<ResponseModel<T>> {
    return this.http.post(endpoint, JSON.stringify(data))
      .then(response => response.json())
      .then(res => {
        return res;
      })
      .catch(error => {
        console.log('Something went wrong.');
        return [];
      });
  }

  putAsync<T>(endpoint: string, data: any): Promise<ResponseModel<T>> {
    return this.http.put(endpoint, JSON.stringify(data))
      .then(response => response.json())
      .then(res => {
        return res;
      })
      .catch(error => {
        console.log('Something went wrong.');
        return [];
      });
  }

  deleteAsnyc<T>(endpoint: string): Promise<ResponseModel<T>> {
    return this.http.delete(endpoint)
      .then(response => response.json())
      .then(res => {
        return res;
      })
      .catch(error => {
        console.log('Something went wrong.');
        return [];
      });
  }
}
