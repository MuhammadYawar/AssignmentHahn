import { APIRoutes } from './../../helper/apiurl';
import { autoinject } from 'aurelia-framework';
import { Applicant } from '../../models/applicant';
import { ResponseModel } from '../../models/response';
import { DataService } from '../data/data.service';

@autoinject
export class ApplicantService {

  _dataService: DataService;
  constructor(dataService: DataService) {
    this._dataService = dataService;
  }

  public async postApplicant(applicant: Applicant): Promise<ResponseModel<Applicant[]>> {
    return  await this._dataService.postAsync(APIRoutes.Applicant.AddApplicant, applicant);
  }
}
 