export class LoadingService {
  showLoader = false;

  // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
  public async loadingDynamicFunction(myfunc) {
    this.showLoader = true;
    const result = await myfunc;
    this.showLoader = false;
    return result;
  }
}
