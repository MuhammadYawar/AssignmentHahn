declare let NAME: string;
declare let VERSION: string;
declare let PLATFORM: string;
declare let CONFIG: IAppConfigEnv;

export interface IAppConfigEnv {
  NAME: string;
  API_MAIN_URL: string;
  API_UAM_URL: string;
  LOG_LEVEL: string;
}

export class AppConfigService {
  private config: IAppConfigEnv;

  constructor() {
    this.config = CONFIG;
  }
  public getConfig(): IAppConfigEnv { return this.config; }
}
