import { autoinject, inject } from 'aurelia-framework';
import { I18N } from 'aurelia-i18n';
import { BindingSignaler } from 'aurelia-templating-resources';

export const LocaleChangedSignal = 'locale:changed';

@autoinject
export class LanguageService {

  constructor(private i18n: I18N) {
  }

  /**
   * Return the language: en, de
   */
  public getCurrentLang(): string {
    return this.getCurrentLocale().split('-')[0];
  }

  /**
   * Get a list of current configured languages which has a translation.
   */
  public getSupportedLanguages(): string[] {
    const languages = Object.keys(this.i18n.i18next.options.fallbackLng)
      .map(key => this.i18n.i18next.options.fallbackLng[key][0].split('-')[0])
      .filter((value, index, array) => {
        return array.indexOf(value) === index;
      });
    return languages;
  }

  public getCurrentLocale(): string {
    return this.i18n.getLocale();
  }
}
