export abstract  class Constants{
  static readonly English = 'English';
  static readonly German = 'German';
}
