export const APIRoutes = {
  Applicant: {
    GetAllApplicants: 'applicants',
    GetApplicantById: 'applicants',
    AddApplicant: 'applicants',
    UpdateApplicant: 'applicants',
    DeleteApplicant: 'applicants',
  }
}
