export class ResponseModel<T>{
    isSuccess: boolean;
    message: string;
    data: T;
    url : string;
    hasData: boolean;

}
