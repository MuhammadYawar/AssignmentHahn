import { ValidationRules } from "aurelia-validation";

export class Applicant {
  id: number;
  name: string;
  familyName: string;
  address: string;
  countryOfOrigin: string;
  emailAddress: string;
  age: number;
  hired: boolean;
}

ValidationRules
  .ensure('name').required().minLength(5).withMessage('Name length must be equal or geater then 5')
  .ensure('familyName').required().minLength(5).withMessage('Name length must be equal or geater then 5')
  .ensure('address').required().minLength(10).withMessage('Name length must be equal or geater then 10')
  .ensure('countryOfOrigin').required().minLength(3)
  .ensure('emailAddress').email().required().withMessage('Please enter your email.')
  .ensure('age').required().min(20).max(60).withMessage('Age must be in betwen 20 to 60')
  .on(Applicant);
