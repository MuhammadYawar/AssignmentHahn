import { PLATFORM } from 'aurelia-pal';
import {FrameworkConfiguration} from 'aurelia-framework';
import { Backend, TCustomAttribute } from 'aurelia-i18n';

export function configure(config: FrameworkConfiguration): void {
  //config.globalResources(['../pages/welcome/welcome', '../app']);
}
