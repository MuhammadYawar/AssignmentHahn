import { LoadingService } from './../../core/services/common/loader.service';
import { ErrorDialog } from './../../global/dialog/error/errordialog';
import { Router } from 'aurelia-router';
import { I18N } from 'aurelia-i18n';
import { LanguageService } from './../../core/services/common/language.service';
import { BootstrapFormRenderer } from './../../global/bootstrapformrenderer';
import { inject } from 'aurelia-dependency-injection';
import { Applicant } from './../../core/models/applicant';
import { validateTrigger, ValidationControllerFactory } from 'aurelia-validation';
import { ApplicantService } from 'core/services/applicant/applicant.service';
import {DialogService} from 'aurelia-dialog';
import { Prompt } from 'global/dialog/confirmation/prompt';
import { Constants } from 'core/helper/constants';
import i18next from 'i18next';

@inject(ValidationControllerFactory, LanguageService, ApplicantService,DialogService, Router, I18N, LoadingService)
export class Welcome {
  public heading = 'Applicant';
  public switchLang = 'German';
  controller = null;
  isDisabled = true;
  isDisallowSubmit = true;
  applicantModel: Applicant = new Applicant();
  _dialogService: DialogService;
  router: Router;
  i18n: I18N;
  _loadingService: LoadingService;
  constructor(private controllerFactory: ValidationControllerFactory, private languageService: LanguageService,
    private applicantService: ApplicantService, dialogService: DialogService, router: Router, i18n: I18N,
    loadingService: LoadingService) {
    this.controller = controllerFactory.createForCurrentScope();
    this.controller.addRenderer(new BootstrapFormRenderer());
    this.controller.validateTrigger = validateTrigger.manual;
    this.controller.addObject(this.applicantModel);
    this._dialogService = dialogService;
    this.router = router;
    this.i18n = i18n;
    this._loadingService = loadingService
  }


  public submit(): void {
    try {
      this.controller.validate({ object: this.applicantModel })
        .then((resp) => {
          if (resp.valid) {
            console.log(resp);
            this._loadingService.showLoader = true;
            this.applicantService.postApplicant(this.applicantModel).then((response) => {
              if (response.isSuccess) {
                this.applicantModel = new Applicant();
                this.controller.reset();
                this._loadingService.showLoader = false;
                this.router.navigate("/success");
              }
              else{
                this._dialogService.open({ viewModel: ErrorDialog, model: response.message == undefined ? this.i18n.tr("wentwrong") : response.message, lock: false});
              }
              this._loadingService.showLoader = false;
            })
          }
        });
    } catch (ex) {
      console.log(ex);
    }
  }

  // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types

  public ResetForm(): void {
    this._dialogService.open({ viewModel: Prompt, model: this.i18n.tr('areyousurerest'), lock: false }).whenClosed(response => {
      if (!response.wasCancelled) {
        this.applicantModel = new Applicant();
        this.controller.reset();
        this.isDisabled = true;
      } else {
        console.log('close');
      }
    });
  

  }

  
  public onChangeValue($event): void {
    if (this.applicantModel.hired || this.applicantModel.address
      || this.applicantModel.age || this.applicantModel.countryOfOrigin
      || this.applicantModel.emailAddress || this.applicantModel.familyName
      || this.applicantModel.name) {
      this.isDisabled = false;
    }
    else {
      this.isDisabled = true;
    }
    this.isAllowSubmit($event.target.name);
  }

  public isAllowSubmit(controlName: string): void {
    this.controller.validate({ object: this.applicantModel, propertyName: controlName });
    if (this.applicantModel.address
      && this.applicantModel.age && this.applicantModel.countryOfOrigin
      && this.applicantModel.emailAddress && this.applicantModel.familyName
      && this.applicantModel.name) {
      this.controller.validate({ object: this.applicantModel }).then((response) => {
        if (response.valid) {
          this.isDisallowSubmit = false;
        }
        else {
          this.isDisallowSubmit = true;
        }
      });
    }
    else {
      this.isDisallowSubmit = true;
    }

  }

  public switchLanguage(): void {
    // eslint-disable-next-line no-debugger
    this.i18n.tr('applicant');
    const lang = this.i18n.getLocale();
    if (lang === this.languageService.getSupportedLanguages()[0]) {
      this.switchLang = Constants.German;
      this.i18n.setLocale(this.languageService.getSupportedLanguages()[1]).then(() => {
        this.heading = this.i18n.tr('applicant');
      });
    } else {
      this.switchLang = Constants.English;
      this.i18n.setLocale(this.languageService.getSupportedLanguages()[0]).then(() => {
        this.heading = this.i18n.tr('applicant');
      });
    }
   
  }

}
