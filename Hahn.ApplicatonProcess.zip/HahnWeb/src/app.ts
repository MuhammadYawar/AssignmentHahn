import { LanguageService } from './core/services/common/language.service';
import { PLATFORM } from 'aurelia-pal';
import { Router, RouterConfiguration } from 'aurelia-router';

export class App {
  public router: Router;
  public configureRouter(config: RouterConfiguration, router: Router): Promise<void> | PromiseLike<void> | void {
    config.title = 'Hahn';
    config.map([
      {
        route: ['', 'success'],
        name: 'success',
        moduleId: PLATFORM.moduleName('./pages/success/success'),
        nav: false,
        title: 'Success'
      },
      {
        route: ['', 'welcome'],
        name: 'welcome',
        moduleId: PLATFORM.moduleName('./pages/welcome/welcome'),
        nav: true,
        title: 'Welcome'
      },
    ]);

    this.router = router;
  }
}
